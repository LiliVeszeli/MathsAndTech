//--------------------------------------------------------------------------------------
// Vector4 class (cut down version), to hold points and vectors
//--------------------------------------------------------------------------------------

#include "CVector4.h"


// No content required here yet (code in header file)